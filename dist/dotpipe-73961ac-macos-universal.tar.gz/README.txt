dotpipe 73961ac - macOS (universal: Apple silicon + Intel)

  chmod +x dotpipe
  xattr -d com.apple.quarantine dotpipe   # once, only if macOS complains
  ./dotpipe -w 1280 -h 720 --vignette 0.7 < in.raw > out.raw

Or build from source instead:  make
